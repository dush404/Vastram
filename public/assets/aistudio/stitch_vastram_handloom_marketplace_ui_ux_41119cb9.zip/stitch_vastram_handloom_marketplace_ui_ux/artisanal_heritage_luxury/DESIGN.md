---
name: Artisanal Heritage Luxury
colors:
  surface: '#fdf9f3'
  surface-dim: '#dddad4'
  surface-bright: '#fdf9f3'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f7f3ed'
  surface-container: '#f1ede7'
  surface-container-high: '#ebe8e2'
  surface-container-highest: '#e6e2dc'
  on-surface: '#1c1c18'
  on-surface-variant: '#57423b'
  inverse-surface: '#31302d'
  inverse-on-surface: '#f4f0ea'
  outline: '#8a726a'
  outline-variant: '#dec0b7'
  surface-tint: '#a23e18'
  primary: '#9f3c16'
  on-primary: '#ffffff'
  primary-container: '#bf542c'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb59c'
  secondary: '#4f5e81'
  on-secondary: '#ffffff'
  secondary-container: '#c5d4fd'
  on-secondary-container: '#4d5b7e'
  tertiary: '#186940'
  on-tertiary: '#ffffff'
  tertiary-container: '#378357'
  on-tertiary-container: '#f6fff5'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbcf'
  primary-fixed-dim: '#ffb59c'
  on-primary-fixed: '#390c00'
  on-primary-fixed-variant: '#822801'
  secondary-fixed: '#d9e2ff'
  secondary-fixed-dim: '#b7c6ee'
  on-secondary-fixed: '#0a1a3a'
  on-secondary-fixed-variant: '#384668'
  tertiary-fixed: '#a5f4bf'
  tertiary-fixed-dim: '#8ad7a5'
  on-tertiary-fixed: '#002110'
  on-tertiary-fixed-variant: '#00522e'
  background: '#fdf9f3'
  on-background: '#1c1c18'
  surface-variant: '#e6e2dc'
typography:
  headline-xl:
    fontFamily: Noto Serif
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Noto Serif
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Noto Serif
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Noto Serif
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: 0em
  headline-md:
    fontFamily: Noto Serif
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Noto Serif
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.06em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-mobile: 0.75rem
  gutter-desktop: 2rem
  margin: 1.5rem
  margin-mobile: 1rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system expresses a dual identity: ancient loom heritage rendered with tactile grace, anchored by high-trust modern commerce utilities. It is designed for two contrasting user personas: global collectors seeking authenticated luxury textiles, and rural weaver collectives needing unambiguous, daylight-readable trade touchpoints.

The visual style blends **Tactile Heritage Luxury** with **Functional Fintech**. The interface rejects cold digital minimalism in favor of warp-and-weft textural warmth, structured editorial hierarchy, and explicit physical metaphors (cloth tags, loom seals, raw paper borders). Physicality is emphasized through porous cream surfaces, terracotta stampings, and crisp botanical green trust markers.

### Core Tenets
- **Woven Integrity:** Surfaces evoke hand-spun tussar and mulberry silks rather than glossy synthetic glass. Textures are subtle, low-frequency SVG-based grain and fine diagonal warp rasters.
- **Radical Transparency:** Prices, artisan margins, Geographical Indication (GI) statuses, and loom origins are displayed as indelible certificates rather than buried fine print.
- **Direct Linkage:** Disintermediation is visual. Communication paths eschew opaque chat widgets in favor of high-contrast, universally accessible direct WhatsApp linkages (`wa.me`).

## Colors

The palette is rooted in indigenous dye baths, sun-baked clay soils, and temple murals of Odisha.

### Palette Architecture
- **Primary (Terracotta / Mati):** `#C85A32` acts as the lead interactive anchor, representing baked earth and natural madder dye. Its deep shade `#A8431F` provides high-contrast press states and focused headers.
- **Secondary (Royal Indigo / Neela):** `#1B2A4A` with deep tint `#111D35` anchors typography, structural footers, and institutional proof marks. It provides the gravitas required for luxury provenance.
- **Tertiary & Trust Accents:**
  - **Forest Green (Aranya):** `#1B6B42` is strictly reserved for GI-tag verifications, weaver fair-trade splits, and authentic provenance badges.
  - **Saffron Turmeric (Haladi):** `#D97706` is reserved for time-sensitive artisan loom updates, pre-order milestones, and award recognitions.
- **Neutral Canvas (Raw Silk & Sand):** `#FAF6F0` (base parchment canvas), `#F3EBDD` (surface cards), and `#EADBC8` (divider borders and inset wells). Pure digital white (`#FFFFFF`) is avoided for broad canvas fills; it is deployed solely for high-contrast tag insets and transaction confirmation chips.

All text pairings must meet WCAG AAA contrast against raw silk backgrounds to guarantee legibility under harsh direct sunlight in open weaver sheds.

## Typography

The typographical pairing creates an editorial dialogue between classical Indian textile literature and frictionless modern commerce interfaces.

- **Display & Headings:** `Noto Serif` brings traditional craft heritage, dignified proportion, and structural warmth. Critically, Noto Serif offers native, harmonious glyph alignment with the Odia script (`Noto Sans Odia` / `Noto Serif Odia`), preventing vertical baseline jitter when Latin titles sit adjacent to Odia artisan names (e.g., ବୟନକାର).
- **Body & Labels:** `Plus Jakarta Sans` provides geometric legibility, wide open counters, and humanistic warmth. It excels in micro-copy, pricing schedules, fiber counts, and technical loom specifications.
- **Multilingual Rules:** When rendering Odia text alongside Latin numerals or titles, line-heights are expanded by `1.2x` on mobile views to preserve diacritic markers (matras) without clipping.

## Layout & Spacing

The layout uses a responsive fluid grid with generous margins that honor editorial catalog layouts. 

- **Grid System:**
  - **Desktop (>= 1024px):** 12-column grid, `margin-desktop` (3rem), `gutter-desktop` (2rem). Content max-width is clamped at `1440px`.
  - **Tablet (768px - 1023px):** 8-column grid, `margin` (1.5rem), `gutter` (1.25rem).
  - **Mobile (< 768px):** 4-column grid, `margin-mobile` (1rem), `gutter-mobile` (0.75rem).
- **Rhythm & Alignment:** Spacing mirrors the cadence of woven reed reeds: tight within functional clusters (`space-xs` and `space-sm` for badge-to-label bindings), structured within card interiors (`space-md` to `space-lg`), and expansive between curated artisan showcases (`space-xl`).
- **Breakpoints:**
  - Mobile: `360px` to `767px`
  - Tablet: `768px` to `1023px`
  - Desktop: `1024px` to `1440px`

## Elevation & Depth

Visual hierarchy rejects harsh drop shadows and neon halos. Depth is generated through **Tonal Weft Layering** combined with **Ambient Clay-Tinted Shadows**.

### Layering Rules
- **Base Canvas (Level 0):** `#FAF6F0` (Raw Silk Cream), solid, un-elevated.
- **Resting Surface (Level 1):** `#F3EBDD` (Sand Paper Card), elevated with an ambient, diffused shadow: `0 4px 20px -2px rgba(168, 67, 31, 0.06), 0 1px 3px 0 rgba(27, 42, 74, 0.04)`. Outlined by a soft 1px border of `#EADBC8`.
- **Raised Interactive / Overlay (Level 2):** Modal sheets, floating provenance cards, and action bars use pure white `#FFFFFF` or softened silk surfaces with `0 12px 32px -4px rgba(168, 67, 31, 0.12), 0 4px 8px -2px rgba(27, 42, 74, 0.06)`.
- **Sunlight Readability:** No critical interface affordance relies entirely on elevation. Every floating or elevated element maintains a high-contrast boundary border (`#EADBC8` or `#C85A32` at reduced opacity) to ensure clear separation in outdoor environments.

## Shapes

The interface balances the organic curvature of draped fabrics with structured utility cards.

- **Base Radius:** Core elements (inputs, standard buttons, notification frames) adhere to `0.5rem` (8px).
- **Curated Cards & Modals:** Elevated display cards, artisan bios, and textile showcases utilize `rounded-2xl` (`1.5rem` / 24px) to simulate the soft, non-rigid edges of folded cloth.
- **Pill Badges & Chips:** GI verification tags, hashtag chips, price tokens, and floating WhatsApp buttons use complete pill forms (`9999px` / `rounded-full`).

## Components

### Buttons
- **Primary Terracotta Action:** Pill or `0.5rem` radius, filled with `#C85A32`, text in `#FAF6F0`, font weight 600. Active/hover state transitions to `#A8431F`.
- **Direct WhatsApp Commerce Trigger:** Floating or fixed action button in high-contrast emerald green (`#1B6B42` or direct WhatsApp brand green `#25D366` when context demands explicit brand recognition). Displays an explicit WhatsApp glyph alongside text: "Inquire Directly with Master Weaver (`wa.me`)". No generic digital chat icons permitted.
- **Secondary Provenance Button:** Transparent background, 1.5px border in `#1B2A4A`, text in `#1B2A4A`.

### Chips & Artisanal Tags
- **Hashtag Chips:** Oval pill enclosures with `#EADBC8` backgrounds and `#1B2A4A` typography (`label-md`). Example: `#KotpadMirgan`, `#SingleIkat`, `#VegetableDye`.
- **GI & Heritage Verification Badges:** Structured micro-capsule components. Left icon slot houses a certified GI or Acoustic Loom mark; right slot houses bold text in `#1B6B42` on a pale leaf tint (`#E8F3EC`).

### Cards
- **Product & Textile Cards:** Bound by `rounded-2xl` corners, coated in `#F3EBDD` with fine `#EADBC8` framing. The image container has a warm neutral placeholder tint with woven cross-stitch loaders.
- **Artisan Bio & Loom Card:** Features a circular artisan portrait overlapping the top margin, bilingual name display (English + Odia Unicode), settlement region, and explicit fair-trade margin disclosure (e.g., "78% direct to weaver household").

### Inputs & Selectors
- **Form Controls:** Set against `#FFFFFF` or `#F3EBDD`, bordered by 1.5px `#EADBC8`. Focus transitions to a 2px ring of `#C85A32`. Labels utilize `label-md` in `#1B2A4A` with high contrast.
- **Checkboxes & Radios:** Rounded square (for checks) and circle (for radios) with `#C85A32` active fills and white handloom-inspired ticks.

### Provenance Certificate Strip
- Dedicated component placed below checkout and product inspection blocks, detailing yarn count, natural dye source, days on loom, and geo-coordinates of the weaving cluster.